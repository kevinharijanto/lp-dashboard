// src/app/page.tsx
"use client";

import { useState } from "react";
import type { ActiveLPPosition } from "@/lib/activeLp";
import { LpCard } from "@/components/LpCard";
import type { ClassifiedTx } from "@/lib/history";
import { classifyHyperscanHistory } from "@/lib/history";
import type {
  HyperscanAddressTxResponse,
  HyperscanNextPageParams,
} from "@/lib/hyperscanTypes";
import { TxCard } from "@/components/TxCard";

const AUTO_HISTORY_PAGE_LIMIT = 5;
const PRJX_PROJECT_ID = "hyper_prjx";

export default function HomePage() {
  const [address, setAddress] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [positions, setPositions] = useState<ActiveLPPosition[]>([]);
  const [txs, setTxs] = useState<ClassifiedTx[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [nextPageParams, setNextPageParams] =
    useState<HyperscanNextPageParams | null>(null);
  const [hasMoreHistory, setHasMoreHistory] = useState<boolean>(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetchInitial();
  };

  const fetchInitial = async () => {
    const addr = address.trim();
    if (!addr) return;

    setLoading(true);
    setError(null);
    setTxs([]);
    setNextPageParams(null);
    setHasMoreHistory(true);

    try {
      // 1) LP positions (same as before)
      const lpRes = await fetch(
        `https://api.rabby.io/v1/user/complex_protocol_list?id=${addr}`
      );
      if (!lpRes.ok) {
        const text = await lpRes.text();
        throw new Error(
          `Rabby LP error ${lpRes.status} ${lpRes.statusText} – ${text.slice(
            0,
            120
          )}`
        );
      }
      const { extractActiveLPPositions } = await import("@/lib/activeLp");
      const lpJson = (await lpRes.json()) as any;
      const lp = extractActiveLPPositions(lpJson);
      setPositions(lp);

      // 2) Auto-load history pages to accumulate PRJX activity
      let cursor: HyperscanNextPageParams | null = null;
      let pagesFetched = 0;

      while (pagesFetched < AUTO_HISTORY_PAGE_LIMIT) {
        const result = await loadHyperscanPage(addr, cursor);
        pagesFetched += 1;
        cursor = result.nextParams;
        if (!result.hasMore || !cursor) {
          break;
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message ?? "Request failed");
      setPositions([]);
      setTxs([]);
    } finally {
      setLoading(false);
    }
  };

type LoadHistoryResult = {
  nextParams: HyperscanNextPageParams | null;
  hasMore: boolean;
};

  const buildHyperscanUrl = (
    addr: string,
    params?: HyperscanNextPageParams | null
  ) => {
    const base = `https://www.hyperscan.com/api/v2/addresses/${addr}/transactions`;
    if (!params) return base;
    const search = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      search.set(key, String(value));
    });
    return `${base}?${search.toString()}`;
  };

  /**
   * Load one page of Hyperscan history, append PRJX txs, keep track of pagination.
   */
  const loadHyperscanPage = async (
    addr: string,
    params?: HyperscanNextPageParams | null
  ): Promise<LoadHistoryResult> => {
    const historyRes = await fetch(buildHyperscanUrl(addr, params));

    if (!historyRes.ok) {
      const text = await historyRes.text();
      console.warn(
        "Hyperscan history error",
        historyRes.status,
        historyRes.statusText,
        text.slice(0, 120)
      );
      setHasMoreHistory(false);
      return {
        nextParams: null,
        hasMore: false,
      };
    }

    const historyJson =
      (await historyRes.json()) as HyperscanAddressTxResponse;

    const classifiedPage = classifyHyperscanHistory(
      historyJson,
      addr
    );
    const prjxTxs = classifiedPage.filter(
      (tx) =>
        tx.projectId === PRJX_PROJECT_ID &&
        tx.category !== "APPROVE" &&
        tx.category !== "SWAP"
    );

    setTxs((prev) => {
      const map = new Map<string, ClassifiedTx>();
      for (const t of [...prev, ...prjxTxs]) {
        map.set(t.hash, t);
      }
      return Array.from(map.values());
    });

    const nextParams = historyJson.next_page_params ?? null;
    const pageHasMore = Boolean(nextParams);
    setHasMoreHistory(pageHasMore);
    setNextPageParams(nextParams);

    return {
      nextParams,
      hasMore: pageHasMore,
    };
  };

  const handleLoadMoreHistory = async () => {
    const addr = address.trim();
    if (!addr || !nextPageParams) return;
    await loadHyperscanPage(addr, nextPageParams);
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-50">
      <div className="mx-auto flex max-w-5xl flex-col gap-8 px-4 py-8">
        {/* Header */}
        <header className="flex flex-col gap-3">
          <h1 className="text-3xl font-bold tracking-tight">
            LP Radar
          </h1>
          <p className="max-w-xl text-sm text-slate-300">
            Paste any EVM wallet address. We show active LP positions
            plus PRJX transaction history (filtered to hyper_prjx).
          </p>
        </header>

        {/* Address input */}
        <section>
          <form
            onSubmit={handleSubmit}
            className="flex flex-col gap-3 sm:flex-row sm:items-center"
          >
            <div className="flex-1">
              <label
                htmlFor="address"
                className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-400"
              >
                EVM wallet address
              </label>
              <input
                id="address"
                type="text"
                className="w-full rounded-xl border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500/70"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                spellCheck={false}
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="mt-2 inline-flex items-center justify-center rounded-xl border border-emerald-500/60 bg-emerald-500/80 px-4 py-2 text-sm font-semibold text-slate-950 shadow hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-60 sm:mt-6"
            >
              {loading ? "Fetching..." : "Fetch data"}
            </button>
          </form>

          {error && (
            <p className="mt-2 text-xs text-red-400">{error}</p>
          )}
        </section>

        {/* LP cards (current snapshot) */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">
              Active LP positions
            </h2>
            {positions.length > 0 && (
              <span className="text-xs text-slate-400">
                {positions.length} position
                {positions.length > 1 ? "s" : ""}
              </span>
            )}
          </div>

          {positions.length === 0 && !loading && !error && (
            <p className="text-sm text-slate-400">
              Nothing found yet. Try an address with LPs.
            </p>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            {positions.map((pos) => (
              <LpCard
                key={`${pos.protocolId}-${pos.positionIndex}`}
                pos={pos}
              />
            ))}
          </div>
        </section>

        {/* PRJX transactions */}
        <section className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-200">
              PRJX transactions
            </h2>
            {txs.length > 0 && (
              <span className="text-xs text-slate-400">
                {txs.length} record{txs.length === 1 ? "" : "s"}
              </span>
            )}
          </div>

          {txs.length === 0 && !loading && (
            <p className="text-sm text-slate-400">
              No PRJX history detected yet for this address.
            </p>
          )}

          <div className="flex flex-col gap-4">
            {txs.map((tx) => (
              <TxCard key={tx.hash} tx={tx} />
            ))}
          </div>

          {hasMoreHistory && nextPageParams && (
            <button
              onClick={handleLoadMoreHistory}
              className="mt-2 self-start rounded-xl border border-slate-700 bg-slate-900/80 px-4 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-800"
            >
              Load older PRJX history
            </button>
          )}
        </section>
      </div>
      
    </main>
  );
}
